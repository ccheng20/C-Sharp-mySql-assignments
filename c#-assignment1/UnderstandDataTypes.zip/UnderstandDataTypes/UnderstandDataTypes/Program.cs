﻿// See https://aka.ms/new-console-template for more information

// Understand data type
//Question1
//A person's telephone number: string
//A person's height: decimal or float
//A person's age: int
//A person's gender: enum (Male, Female, PreferNotToAnswer)
//A person's salary: decimal or double
//A book's ISBN: string
//A book's price: decimal or double
//A book's shipping weight: decimal or float
//A country's population: long
//The number of stars in the universe: long
//The number of employees in each of the small or medium businesses in the United Kingdom: int

// Question 2
//Value Types: Value types are variables that hold a value directly in memory
//Reference Types: Reference types are variables that hold a reference to a location in memory where the value is stored. 
// boxing: Boxing is the process of converting a value type to a reference type by encapsulating it in an object.
// unboxing:Unboxing is the opposite of boxing, and it is the process of converting a reference type back to a value type.

//Question 3
// Managed resources are resources that are managed by the .NET Framework's garbage collector.
//Unmanaged resources are resources that are not managed by the .NET Framework's garbage collector.

//Question4
//The Garbage Collector (GC) in.NET is a memory management feature that automatically manages
//the allocation and release of memory used by .NET applications.

//Playing with Console App

Console.WriteLine("What is your favorite color?");
String? favColor = Console.ReadLine();
Console.WriteLine("My favorite color is " + favColor);




