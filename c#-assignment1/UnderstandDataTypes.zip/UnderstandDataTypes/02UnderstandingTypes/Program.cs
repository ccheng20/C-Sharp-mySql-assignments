﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");
Console.WriteLine("Number types in C#:");
Console.WriteLine("--------------------\n");

Console.WriteLine("sbyte: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(sbyte), sbyte.MinValue, sbyte.MaxValue);
Console.WriteLine("byte: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(byte), byte.MinValue, byte.MaxValue);
Console.WriteLine("short: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(short), short.MinValue, short.MaxValue);
Console.WriteLine("ushort: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(ushort), ushort.MinValue, ushort.MaxValue);
Console.WriteLine("int: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(int), int.MinValue, int.MaxValue);
Console.WriteLine("uint: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(uint), uint.MinValue, uint.MaxValue);
Console.WriteLine("long: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(long), long.MinValue, long.MaxValue);
Console.WriteLine("ulong: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(ulong), ulong.MinValue, ulong.MaxValue);
Console.WriteLine("float: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(float), float.MinValue, float.MaxValue);
Console.WriteLine("double: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(double), double.MinValue, double.MaxValue);
Console.WriteLine("decimal: {0} bytes, MinValue: {1}, MaxValue: {2}", sizeof(decimal), decimal.MinValue, decimal.MaxValue);

Console.WriteLine("\nEnter your centuries: ");
int centuries = int.Parse(Console.ReadLine()!);

long years = centuries * 100L;
long days = years * 365L;
long hours = days * 24L;
long minutes = hours * 60L;
long seconds = minutes * 60L;
long milliseconds = seconds * 1000L;
long microseconds = milliseconds * 1000L;
long nanoseconds = microseconds * 1000L;

Console.WriteLine("\n{0} centuries = {1} years = {2} days = {3} hours = {4} minutes = {5} seconds = {6} milliseconds = {7} microseconds = {8} nanoseconds",
                centuries, years, days, hours, minutes, seconds, milliseconds, microseconds, nanoseconds);

Console.ReadLine();

//Controlling Flow and Converting Types
//1.When you divide an int variable by 0 in C#, it will throw an exception of type System.DivideByZeroException at runtime.
//2.When you divide a double variable by 0 in C#, the result will be either positive infinity, negative infinity,
//or NaN (not a number), depending on the sign and type of the operands.
//3.When you overflow an int variable in C#, it will wrap around and start again from the opposite end of the range.
//4.x = y++ assigns the value of y to x and then increments y by 1. x = ++y increments y by 1 and then assigns the new value of y to x.
//5.break is used to exit a loop completely, continue is used to skip to the next iteration of a loop, and return is used to exit a method and return a value.
//6.The three parts of a for statement are: initialization, condition, and increment/decrement.
//Initialization is the code that runs before the loop starts, condition is the boolean expression that is evaluated at the beginning of
//each loop iteration to determine whether to continue or exit the loop, and increment/decrement is the code that runs at the end of each loop iteration.

//7.The = operator is used to assign a value to a variable, while the == operator is used to compare two values for equality.
//8.Yes, the following statement is a valid infinite loop in C#: for ( ; true; ) ;
//9.In a switch expression, the underscore _ is used as a discard pattern to match any value that is not explicitly handled by the switch cases.
//10.An object must implement the IEnumerable interface (or the IEnumerable<T> interface) to be enumerated over by using the foreach statement in C#. This interface defines the GetEnumerator method, which returns an IEnumerator (or IEnumerator<T>)
//object that provides the iteration logic for the collection.

